import {
  Component,
  OnInit,
  OnDestroy,
  AfterViewInit,
  ViewChild,
  ElementRef,
  ApplicationRef,
  createComponent,
  EnvironmentInjector,
  ComponentRef,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';

import {
  GoldenLayout,
  LayoutConfig,
  ComponentItemConfig,
  ComponentContainer,
  RowOrColumnItemConfig,
  StackItemConfig,
  ItemType,
  ResolvedComponentItemConfig
} from 'golden-layout';

import { LayoutService } from './services/layout.service';
import { GraphService } from './services/graph.service';
import { MenubarComponent } from './components/menubar/menubar.component';
import { StatusbarComponent } from './components/statusbar/statusbar.component';
import { MainViewComponent } from './components/main-view/main-view.component';
import { TreeViewComponent } from './components/tree-view/tree-view.component';
import { BirdViewComponent } from './components/bird-view/bird-view.component';
import { ConsolePanelComponent } from './components/console-panel/console-panel.component';

// Re-export for convenience
export { MenubarComponent, StatusbarComponent };

// Component registration names for GoldenLayout
export const GL_COMPONENT = {
  MAIN_VIEW:  'MainView',
  TREE_VIEW:  'TreeView',
  BIRD_VIEW:  'BirdView',
  CONSOLE:    'Console',
} as const;

type GlComponentName = typeof GL_COMPONENT[keyof typeof GL_COMPONENT];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, MenubarComponent, StatusbarComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit, OnDestroy {

  @ViewChild('glContainer', { static: true }) glContainerRef!: ElementRef<HTMLDivElement>;

  private goldenLayout!: GoldenLayout;
  private componentRefs = new Map<ComponentContainer, ComponentRef<any>>();
  private subscriptions = new Subscription();

  private appRef        = inject(ApplicationRef);
  private envInjector   = inject(EnvironmentInjector);
  layoutService         = inject(LayoutService);
  graphService          = inject(GraphService);

  ngAfterViewInit(): void {
    this.initGoldenLayout();
    this.subscribeToLayoutChanges();
  }

  private initGoldenLayout(): void {
    const config: LayoutConfig = {
      settings: {
        showPopoutIcon: false,
        showMaximiseIcon: true,
        showCloseIcon: true,
        responsiveMode: 'always',
      },
      dimensions: {
        borderWidth: 4,
        headerHeight: 32,
      },
      root: {
        type: ItemType.column,
        content: [
          // Top section: Tree + BirdView + Main
          {
            type: ItemType.row,
            size: '75%',
            content: [
              // Left sidebar: Tree View
              {
                type: ItemType.stack,
                size: '22%',
                content: [{
                  type: ItemType.component,
                  componentType: GL_COMPONENT.TREE_VIEW,
                  title: '🌲 Tree View',
                  isClosable: false,
                } as ComponentItemConfig]
              } as StackItemConfig,
              // Middle-left: Bird View
              {
                type: ItemType.stack,
                size: '18%',
                content: [{
                  type: ItemType.component,
                  componentType: GL_COMPONENT.BIRD_VIEW,
                  title: '🐦 Bird View',
                  isClosable: false,
                } as ComponentItemConfig]
              } as StackItemConfig,
              // Main area
              {
                type: ItemType.stack,
                size: '60%',
                content: [{
                  type: ItemType.component,
                  componentType: GL_COMPONENT.MAIN_VIEW,
                  title: '◈ Main View',
                  isClosable: false,
                } as ComponentItemConfig]
              } as StackItemConfig,
            ]
          } as RowOrColumnItemConfig,
          // Bottom: Console
          {
            type: ItemType.stack,
            size: '25%',
            content: [{
              type: ItemType.component,
              componentType: GL_COMPONENT.CONSOLE,
              title: '⬛ Console',
              isClosable: true,
            } as ComponentItemConfig]
          } as StackItemConfig,
        ]
      } as RowOrColumnItemConfig
    };

    this.goldenLayout = new GoldenLayout(this.glContainerRef.nativeElement);

    // Register virtual components (Angular-friendly approach)
    this.goldenLayout.registerComponentFactoryFunction(
      GL_COMPONENT.MAIN_VIEW,
      (container) => this.createAngularComponent(MainViewComponent, container)
    );
    this.goldenLayout.registerComponentFactoryFunction(
      GL_COMPONENT.TREE_VIEW,
      (container) => this.createAngularComponent(TreeViewComponent, container)
    );
    this.goldenLayout.registerComponentFactoryFunction(
      GL_COMPONENT.BIRD_VIEW,
      (container) => this.createAngularComponent(BirdViewComponent, container)
    );
    this.goldenLayout.registerComponentFactoryFunction(
      GL_COMPONENT.CONSOLE,
      (container) => this.createAngularComponent(ConsolePanelComponent, container)
    );

    this.goldenLayout.loadLayout(config);

    // Handle window resize
    const resizeObserver = new ResizeObserver(() => {
      this.goldenLayout.updateRootSize();
    });
    resizeObserver.observe(this.glContainerRef.nativeElement);
  }

  private createAngularComponent<T>(componentClass: any, container: ComponentContainer): void {
    const componentRef = createComponent(componentClass, {
      environmentInjector: this.envInjector,
    });

    this.appRef.attachView(componentRef.hostView);
    container.element.appendChild(componentRef.location.nativeElement);
    this.componentRefs.set(container, componentRef);

    container.on('destroy', () => {
      this.appRef.detachView(componentRef.hostView);
      componentRef.destroy();
      this.componentRefs.delete(container);
    });
  }

  private subscribeToLayoutChanges(): void {
    this.subscriptions.add(
      this.layoutService.consoleVisible$.subscribe(visible => {
        // Console toggle handled via GoldenLayout item visibility
        // In a full implementation, find the console item and toggle it
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
    if (this.goldenLayout) {
      this.goldenLayout.destroy();
    }
    this.componentRefs.forEach(ref => ref.destroy());
  }
}
