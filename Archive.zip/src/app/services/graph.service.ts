import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type NodeValueType = number | string | Date;

export interface GraphNode {
  id: string;
  label: string;
  properties: Record<string, NodeValueType>;
  x?: number;
  y?: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  directed: boolean;
}

export interface Graph {
  id: string;
  name: string;
  nodes: GraphNode[];
  edges: GraphEdge[];
  directed: boolean;
  acyclic: boolean;
}

@Injectable({ providedIn: 'root' })
export class GraphService {

  private _graph = new BehaviorSubject<Graph | null>(null);
  graph$ = this._graph.asObservable();

  loadDemoGraph(): void {
    const demo: Graph = {
      id: 'demo-1',
      name: 'Demo Graph',
      directed: true,
      acyclic: false,
      nodes: [
        { id: 'n1', label: 'Node A', properties: { type: 'root', value: 42, since: new Date('2023-01-01') }, x: 400, y: 200 },
        { id: 'n2', label: 'Node B', properties: { type: 'child', value: 3.14 }, x: 200, y: 380 },
        { id: 'n3', label: 'Node C', properties: { type: 'child', value: 'hello' }, x: 600, y: 380 },
        { id: 'n4', label: 'Node D', properties: { type: 'leaf', value: 99 }, x: 100, y: 560 },
        { id: 'n5', label: 'Node E', properties: { type: 'leaf', value: 7 }, x: 300, y: 560 },
        { id: 'n6', label: 'Node F', properties: { type: 'leaf', value: 'world' }, x: 700, y: 560 },
      ],
      edges: [
        { id: 'e1', source: 'n1', target: 'n2', directed: true },
        { id: 'e2', source: 'n1', target: 'n3', directed: true },
        { id: 'e3', source: 'n2', target: 'n4', directed: true },
        { id: 'e4', source: 'n2', target: 'n5', directed: true },
        { id: 'e5', source: 'n3', target: 'n6', directed: true },
        { id: 'e6', source: 'n4', target: 'n1', directed: true, label: 'cycle' },
      ]
    };
    this._graph.next(demo);
  }

  getGraph(): Graph | null {
    return this._graph.value;
  }

  setGraph(graph: Graph): void {
    this._graph.next(graph);
  }
}
