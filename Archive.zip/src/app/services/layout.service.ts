import { Injectable, signal, computed } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type PanelId = 'treeView' | 'birdView' | 'mainView' | 'console';

export interface PanelState {
  treeView: boolean;
  birdView: boolean;
  mainView: boolean;
  console: boolean;
}

export interface ConsoleMessage {
  level: 'info' | 'warn' | 'error' | 'success';
  timestamp: Date;
  message: string;
}

@Injectable({ providedIn: 'root' })
export class LayoutService {

  // Panel visibility state
  private _panelState = new BehaviorSubject<PanelState>({
    treeView: true,
    birdView: true,
    mainView: true,
    console: true
  });
  panelState$ = this._panelState.asObservable();

  // Console messages
  private _consoleMessages = new BehaviorSubject<ConsoleMessage[]>([]);
  consoleMessages$ = this._consoleMessages.asObservable();

  // Selected node (for cross-panel sync)
  private _selectedNodeId = new BehaviorSubject<string | null>(null);
  selectedNodeId$ = this._selectedNodeId.asObservable();

  // Console visibility
  private _consoleVisible = new BehaviorSubject<boolean>(true);
  consoleVisible$ = this._consoleVisible.asObservable();

  constructor() {
    this.log('info', 'Nessie platform initialized');
    this.log('info', 'Waiting for graph data source...');
  }

  togglePanel(panelId: PanelId): void {
    const current = this._panelState.value;
    this._panelState.next({ ...current, [panelId]: !current[panelId] });
  }

  isPanelVisible(panelId: PanelId): boolean {
    return this._panelState.value[panelId];
  }

  selectNode(nodeId: string | null): void {
    this._selectedNodeId.next(nodeId);
    if (nodeId) {
      this.log('info', `Node selected: ${nodeId}`);
    }
  }

  toggleConsole(): void {
    const current = this._consoleVisible.value;
    this._consoleVisible.next(!current);
  }

  log(level: ConsoleMessage['level'], message: string): void {
    const messages = this._consoleMessages.value;
    this._consoleMessages.next([
      ...messages,
      { level, timestamp: new Date(), message }
    ]);
  }

  clearConsole(): void {
    this._consoleMessages.next([]);
  }
}
