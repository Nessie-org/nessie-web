import {
  Component, OnInit, OnDestroy, AfterViewInit,
  ViewChild, ElementRef, inject, HostListener
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { GraphService, Graph, GraphNode, GraphEdge } from '../../services/graph.service';
import { LayoutService } from '../../services/layout.service';

@Component({
  selector: 'app-main-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './main-view.component.html',
  styleUrls: ['./main-view.component.scss']
})
export class MainViewComponent implements AfterViewInit, OnDestroy {

  @ViewChild('canvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('wrapper', { static: true }) wrapperRef!: ElementRef<HTMLDivElement>;

  graphService  = inject(GraphService);
  layoutService = inject(LayoutService);

  private ctx!: CanvasRenderingContext2D;
  private graph: Graph | null = null;
  private subscriptions = new Subscription();

  // Pan & Zoom state
  panX = 0;
  panY = 0;
  scale = 1;
  protected isPanning = false;
  private panStart = { x: 0, y: 0 };
  private panOrigin = { x: 0, y: 0 };

  // Hover / Selection
  hoveredNodeId: string | null = null;
  selectedNodeId: string | null = null;

  // View mode
  viewMode: 'simple' | 'block' = 'simple';

  ngAfterViewInit(): void {
    this.setupCanvas();
    this.subscriptions.add(
      this.graphService.graph$.subscribe(graph => {
        this.graph = graph;
        if (graph) {
          this.fitToScreen();
          this.layoutService.log('success', `Graph "${graph.name}" loaded — ${graph.nodes.length} nodes, ${graph.edges.length} edges`);
        }
        this.render();
      })
    );
    this.subscriptions.add(
      this.layoutService.selectedNodeId$.subscribe(id => {
        this.selectedNodeId = id;
        this.render();
      })
    );

    const resizeObserver = new ResizeObserver(() => {
      this.resizeCanvas();
      this.render();
    });
    resizeObserver.observe(this.wrapperRef.nativeElement);
  }

  private setupCanvas(): void {
    const canvas = this.canvasRef.nativeElement;
    this.ctx = canvas.getContext('2d')!;
    this.resizeCanvas();
    this.render();
  }

  resizeCanvas(): void {
    const wrapper = this.wrapperRef.nativeElement;
    const canvas = this.canvasRef.nativeElement;
    canvas.width = wrapper.clientWidth;
    canvas.height = wrapper.clientHeight;
  }

  fitToScreen(): void {
    if (!this.graph || this.graph.nodes.length === 0) return;
    const canvas = this.canvasRef.nativeElement;
    const padding = 60;
    const xs = this.graph.nodes.map(n => n.x ?? 0);
    const ys = this.graph.nodes.map(n => n.y ?? 0);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const gw = maxX - minX || 1, gh = maxY - minY || 1;
    const scaleX = (canvas.width - padding * 2) / gw;
    const scaleY = (canvas.height - padding * 2) / gh;
    this.scale = Math.min(scaleX, scaleY, 2);
    this.panX = (canvas.width - gw * this.scale) / 2 - minX * this.scale;
    this.panY = (canvas.height - gh * this.scale) / 2 - minY * this.scale;
  }

  render(): void {
    if (!this.ctx) return;
    const canvas = this.canvasRef.nativeElement;
    const ctx = this.ctx;

    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Background grid
    this.drawGrid(ctx, canvas.width, canvas.height);

    if (!this.graph) {
      this.drawEmptyState(ctx, canvas.width, canvas.height);
      return;
    }

    ctx.save();
    ctx.translate(this.panX, this.panY);
    ctx.scale(this.scale, this.scale);

    // Draw edges
    for (const edge of this.graph.edges) {
      this.drawEdge(ctx, edge);
    }

    // Draw nodes
    for (const node of this.graph.nodes) {
      this.drawNode(ctx, node);
    }

    ctx.restore();
  }

  private drawGrid(ctx: CanvasRenderingContext2D, w: number, h: number): void {
    const gridSize = 40;
    ctx.strokeStyle = 'rgba(30, 74, 122, 0.25)';
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    for (let x = 0; x < w; x += gridSize) {
      ctx.moveTo(x, 0); ctx.lineTo(x, h);
    }
    for (let y = 0; y < h; y += gridSize) {
      ctx.moveTo(0, y); ctx.lineTo(w, y);
    }
    ctx.stroke();
  }

  private drawEmptyState(ctx: CanvasRenderingContext2D, w: number, h: number): void {
    ctx.fillStyle = 'rgba(42, 106, 170, 0.08)';
    ctx.font = '16px Rajdhani, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No graph loaded — use File › Load Demo Graph', w / 2, h / 2);
    ctx.fillStyle = 'rgba(0, 200, 248, 0.2)';
    ctx.font = '64px serif';
    ctx.fillText('⬡', w / 2, h / 2 - 60);
  }

  private drawEdge(ctx: CanvasRenderingContext2D, edge: GraphEdge): void {
    const src = this.graph!.nodes.find(n => n.id === edge.source);
    const tgt = this.graph!.nodes.find(n => n.id === edge.target);
    if (!src || !tgt) return;

    const sx = src.x ?? 0, sy = src.y ?? 0;
    const tx = tgt.x ?? 0, ty = tgt.y ?? 0;

    ctx.beginPath();
    ctx.strokeStyle = 'rgba(0, 180, 220, 0.45)';
    ctx.lineWidth = 1.5;

    if (edge.source === edge.target) {
      // Self-loop
      ctx.arc(sx + 30, sy - 30, 20, 0, Math.PI * 2);
    } else {
      ctx.moveTo(sx, sy);
      ctx.lineTo(tx, ty);
    }
    ctx.stroke();

    // Arrow for directed
    if (edge.directed && edge.source !== edge.target) {
      this.drawArrow(ctx, sx, sy, tx, ty);
    }

    // Edge label
    if (edge.label) {
      const mx = (sx + tx) / 2, my = (sy + ty) / 2;
      ctx.fillStyle = 'rgba(0, 180, 220, 0.7)';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(edge.label, mx, my - 6);
    }
  }

  private drawArrow(ctx: CanvasRenderingContext2D, sx: number, sy: number, tx: number, ty: number): void {
    const nodeRadius = 22;
    const angle = Math.atan2(ty - sy, tx - sx);
    const ex = tx - nodeRadius * Math.cos(angle);
    const ey = ty - nodeRadius * Math.sin(angle);
    const arrowLen = 10;
    const arrowAngle = 0.45;

    ctx.beginPath();
    ctx.fillStyle = 'rgba(0, 180, 220, 0.6)';
    ctx.moveTo(ex, ey);
    ctx.lineTo(ex - arrowLen * Math.cos(angle - arrowAngle), ey - arrowLen * Math.sin(angle - arrowAngle));
    ctx.lineTo(ex - arrowLen * Math.cos(angle + arrowAngle), ey - arrowLen * Math.sin(angle + arrowAngle));
    ctx.closePath();
    ctx.fill();
  }

  private drawNode(ctx: CanvasRenderingContext2D, node: GraphNode): void {
    const x = node.x ?? 0, y = node.y ?? 0;
    const r = 22;
    const isSelected = node.id === this.selectedNodeId;
    const isHovered = node.id === this.hoveredNodeId;

    // Glow for selected/hovered
    if (isSelected || isHovered) {
      ctx.beginPath();
      ctx.arc(x, y, r + 8, 0, Math.PI * 2);
      ctx.fillStyle = isSelected
        ? 'rgba(0, 200, 248, 0.2)'
        : 'rgba(0, 200, 248, 0.1)';
      ctx.fill();
    }

    // Node circle
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);

    // Fill
    const gradient = ctx.createRadialGradient(x - 5, y - 5, 2, x, y, r);
    if (isSelected) {
      gradient.addColorStop(0, '#1a6090');
      gradient.addColorStop(1, '#0a3060');
    } else if (isHovered) {
      gradient.addColorStop(0, '#155070');
      gradient.addColorStop(1, '#082040');
    } else {
      gradient.addColorStop(0, '#0f3050');
      gradient.addColorStop(1, '#061828');
    }
    ctx.fillStyle = gradient;
    ctx.fill();

    // Border
    ctx.strokeStyle = isSelected ? '#00c8f8' : isHovered ? '#0099cc' : '#1e4a7a';
    ctx.lineWidth = isSelected ? 2.5 : 1.5;
    ctx.stroke();

    // Label
    ctx.fillStyle = isSelected ? '#00c8f8' : '#8ab4d4';
    ctx.font = `${isSelected ? 600 : 400} 11px Rajdhani, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(node.label, x, y);

    // ID label below
    ctx.fillStyle = 'rgba(138, 180, 212, 0.4)';
    ctx.font = '9px JetBrains Mono, monospace';
    ctx.fillText(node.id, x, y + r + 10);
  }

  // === Mouse Events ===

  onMouseDown(event: MouseEvent): void {
    if (event.button === 0) {
      this.isPanning = true;
      this.panStart = { x: event.clientX, y: event.clientY };
      this.panOrigin = { x: this.panX, y: this.panY };
    }
  }

  onMouseMove(event: MouseEvent): void {
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const mx = event.clientX - rect.left;
    const my = event.clientY - rect.top;

    if (this.isPanning) {
      this.panX = this.panOrigin.x + (event.clientX - this.panStart.x);
      this.panY = this.panOrigin.y + (event.clientY - this.panStart.y);
      this.render();
      return;
    }

    // Hover detection
    if (this.graph) {
      const worldX = (mx - this.panX) / this.scale;
      const worldY = (my - this.panY) / this.scale;
      const hovered = this.graph.nodes.find(n => {
        const dx = (n.x ?? 0) - worldX;
        const dy = (n.y ?? 0) - worldY;
        return Math.sqrt(dx * dx + dy * dy) < 24;
      });
      const newId = hovered?.id ?? null;
      if (newId !== this.hoveredNodeId) {
        this.hoveredNodeId = newId;
        this.render();
      }
    }
  }

  onMouseUp(event: MouseEvent): void {
    if (this.isPanning) {
      const dx = Math.abs(event.clientX - this.panStart.x);
      const dy = Math.abs(event.clientY - this.panStart.y);
      if (dx < 4 && dy < 4 && this.hoveredNodeId) {
        // Click on node
        this.layoutService.selectNode(this.hoveredNodeId);
      } else if (dx < 4 && dy < 4) {
        this.layoutService.selectNode(null);
      }
      this.isPanning = false;
    }
  }

  onWheel(event: WheelEvent): void {
    event.preventDefault();
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const mx = event.clientX - rect.left;
    const my = event.clientY - rect.top;
    const delta = event.deltaY > 0 ? 0.9 : 1.1;
    this.panX = mx - (mx - this.panX) * delta;
    this.panY = my - (my - this.panY) * delta;
    this.scale = Math.max(0.1, Math.min(8, this.scale * delta));
    this.render();
  }

  setViewMode(mode: 'simple' | 'block'): void {
    this.viewMode = mode;
    this.render();
  }

  loadDemo(): void {
    this.graphService.loadDemoGraph();
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
