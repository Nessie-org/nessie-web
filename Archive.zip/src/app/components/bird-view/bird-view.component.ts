import {
  Component, OnDestroy, AfterViewInit,
  ViewChild, ElementRef, inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { GraphService, Graph } from '../../services/graph.service';
import { LayoutService } from '../../services/layout.service';

@Component({
  selector: 'app-bird-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bird-view.component.html',
  styleUrls: ['./bird-view.component.scss']
})
export class BirdViewComponent implements AfterViewInit, OnDestroy {

  @ViewChild('canvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('wrapper', { static: true }) wrapperRef!: ElementRef<HTMLDivElement>;

  graphService  = inject(GraphService);
  layoutService = inject(LayoutService);

  private ctx!: CanvasRenderingContext2D;
  private graph: Graph | null = null;
  private subscriptions = new Subscription();
  selectedNodeId: string | null = null;

  ngAfterViewInit(): void {
    const canvas = this.canvasRef.nativeElement;
    this.ctx = canvas.getContext('2d')!;

    const resizeObserver = new ResizeObserver(() => {
      const wrapper = this.wrapperRef.nativeElement;
      canvas.width = wrapper.clientWidth;
      canvas.height = wrapper.clientHeight;
      this.render();
    });
    resizeObserver.observe(this.wrapperRef.nativeElement);

    this.subscriptions.add(
      this.graphService.graph$.subscribe(graph => {
        this.graph = graph;
        this.render();
      })
    );

    this.subscriptions.add(
      this.layoutService.selectedNodeId$.subscribe(id => {
        this.selectedNodeId = id;
        this.render();
      })
    );
  }

  render(): void {
    if (!this.ctx) return;
    const canvas = this.canvasRef.nativeElement;
    const ctx = this.ctx;
    const W = canvas.width, H = canvas.height;

    ctx.clearRect(0, 0, W, H);

    // Background
    ctx.fillStyle = '#060e1a';
    ctx.fillRect(0, 0, W, H);

    // Border glow
    ctx.strokeStyle = 'rgba(0, 200, 248, 0.12)';
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, W, H);

    if (!this.graph || this.graph.nodes.length === 0) {
      ctx.fillStyle = 'rgba(42, 106, 170, 0.15)';
      ctx.font = '11px Rajdhani, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Waiting for graph…', W / 2, H / 2);
      return;
    }

    const padding = 16;
    const xs = this.graph.nodes.map(n => n.x ?? 0);
    const ys = this.graph.nodes.map(n => n.y ?? 0);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const gw = maxX - minX || 1, gh = maxY - minY || 1;

    const scaleX = (W - padding * 2) / gw;
    const scaleY = (H - padding * 2) / gh;
    const scale = Math.min(scaleX, scaleY);
    const offsetX = padding + (W - padding * 2 - gw * scale) / 2;
    const offsetY = padding + (H - padding * 2 - gh * scale) / 2;

    const toScreen = (x: number, y: number) => ({
      sx: offsetX + (x - minX) * scale,
      sy: offsetY + (y - minY) * scale
    });

    // Draw edges
    ctx.strokeStyle = 'rgba(0, 150, 200, 0.3)';
    ctx.lineWidth = 0.8;
    for (const edge of this.graph.edges) {
      const src = this.graph.nodes.find(n => n.id === edge.source);
      const tgt = this.graph.nodes.find(n => n.id === edge.target);
      if (!src || !tgt || src.id === tgt.id) continue;
      const s = toScreen(src.x ?? 0, src.y ?? 0);
      const t = toScreen(tgt.x ?? 0, tgt.y ?? 0);
      ctx.beginPath();
      ctx.moveTo(s.sx, s.sy);
      ctx.lineTo(t.sx, t.sy);
      ctx.stroke();
    }

    // Draw nodes
    const nodeR = Math.max(3, Math.min(6, scale * 10));
    for (const node of this.graph.nodes) {
      const { sx, sy } = toScreen(node.x ?? 0, node.y ?? 0);
      const isSelected = node.id === this.selectedNodeId;

      ctx.beginPath();
      ctx.arc(sx, sy, nodeR + (isSelected ? 3 : 0), 0, Math.PI * 2);
      ctx.fillStyle = isSelected ? 'rgba(0, 200, 248, 0.3)' : 'transparent';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(sx, sy, nodeR, 0, Math.PI * 2);
      ctx.fillStyle = isSelected ? '#00c8f8' : '#0f4070';
      ctx.fill();
      ctx.strokeStyle = isSelected ? '#00c8f8' : '#1e4a7a';
      ctx.lineWidth = isSelected ? 1.5 : 0.8;
      ctx.stroke();
    }
  }

  onCanvasClick(event: MouseEvent): void {
    if (!this.graph) return;
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    const mx = event.clientX - rect.left;
    const my = event.clientY - rect.top;

    const W = canvas.width, H = canvas.height;
    const padding = 16;
    const xs = this.graph.nodes.map(n => n.x ?? 0);
    const ys = this.graph.nodes.map(n => n.y ?? 0);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const gw = maxX - minX || 1, gh = maxY - minY || 1;
    const scaleX = (W - padding * 2) / gw;
    const scaleY = (H - padding * 2) / gh;
    const scale = Math.min(scaleX, scaleY);
    const offsetX = padding + (W - padding * 2 - gw * scale) / 2;
    const offsetY = padding + (H - padding * 2 - gh * scale) / 2;

    const worldX = (mx - offsetX) / scale + minX;
    const worldY = (my - offsetY) / scale + minY;

    const hit = this.graph.nodes.find(n => {
      const dx = (n.x ?? 0) - worldX;
      const dy = (n.y ?? 0) - worldY;
      return Math.sqrt(dx * dx + dy * dy) < 30;
    });

    this.layoutService.selectNode(hit?.id ?? null);
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
