import { Component, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { GraphService, Graph, GraphNode } from '../../services/graph.service';
import { LayoutService } from '../../services/layout.service';

export interface TreeNode {
  graphNode: GraphNode;
  children: TreeNode[];
  expanded: boolean;
  depth: number;
  isRecursive?: boolean;
}

@Component({
  selector: 'app-tree-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tree-view.component.html',
  styleUrls: ['./tree-view.component.scss']
})
export class TreeViewComponent implements OnDestroy {

  graphService  = inject(GraphService);
  layoutService = inject(LayoutService);

  treeRoot: TreeNode | null = null;
  selectedNodeId: string | null = null;

  private subscriptions = new Subscription();

  constructor() {
    this.subscriptions.add(
      this.graphService.graph$.subscribe(graph => {
        this.buildTree(graph);
      })
    );
    this.subscriptions.add(
      this.layoutService.selectedNodeId$.subscribe(id => {
        this.selectedNodeId = id;
      })
    );
  }

  private buildTree(graph: Graph | null): void {
    if (!graph || graph.nodes.length === 0) {
      this.treeRoot = null;
      return;
    }

    // Find root: node with no incoming edges (or first node as fallback)
    const hasIncoming = new Set(graph.edges.map(e => e.target));
    const rootNode = graph.nodes.find(n => !hasIncoming.has(n.id)) ?? graph.nodes[0];

    this.treeRoot = this.buildTreeNode(rootNode, graph, new Set(), 0);
  }

  private buildTreeNode(node: GraphNode, graph: Graph, visited: Set<string>, depth: number): TreeNode {
    const isRecursive = visited.has(node.id);
    const treeNode: TreeNode = {
      graphNode: node,
      children: [],
      expanded: depth < 2,
      depth,
      isRecursive
    };

    if (!isRecursive) {
      visited.add(node.id);
      const childEdges = graph.edges.filter(e => e.source === node.id);
      treeNode.children = childEdges.map(e => {
        const childNode = graph.nodes.find(n => n.id === e.target);
        if (!childNode) return null;
        return this.buildTreeNode(childNode, graph, new Set(visited), depth + 1);
      }).filter(Boolean) as TreeNode[];
    }

    return treeNode;
  }

  toggleNode(node: TreeNode): void {
    node.expanded = !node.expanded;
  }

  selectNode(node: TreeNode): void {
    this.layoutService.selectNode(node.graphNode.id);
  }

  getNodeIcon(node: TreeNode): string {
    if (node.isRecursive) return '↺';
    if (node.children.length === 0) return '◆';
    return node.expanded ? '▼' : '▶';
  }

  formatProperties(node: GraphNode): string {
    return Object.entries(node.properties)
      .map(([k, v]) => `${k}: ${v instanceof Date ? v.toLocaleDateString() : v}`)
      .join(', ');
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
