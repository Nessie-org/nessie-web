import { Component, inject, ElementRef, ViewChild, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutService, ConsoleMessage } from '../../services/layout.service';

@Component({
  selector: 'app-console-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './console-panel.component.html',
  styleUrls: ['./console-panel.component.scss']
})
export class ConsolePanelComponent implements AfterViewChecked {

  @ViewChild('logContainer') logContainerRef!: ElementRef<HTMLDivElement>;

  layoutService = inject(LayoutService);
  messages$ = this.layoutService.consoleMessages$;

  private shouldScrollToBottom = true;

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
    }
  }

  private scrollToBottom(): void {
    if (this.logContainerRef) {
      const el = this.logContainerRef.nativeElement;
      el.scrollTop = el.scrollHeight;
    }
  }

  clearConsole(): void {
    this.layoutService.clearConsole();
  }

  getLevelIcon(level: ConsoleMessage['level']): string {
    const icons = { info: 'ℹ', warn: '⚠', error: '✖', success: '✔' };
    return icons[level];
  }

  formatTime(date: Date): string {
    return date.toLocaleTimeString('en-US', { hour12: false });
  }

  trackByIndex(index: number): number {
    return index;
  }
}
