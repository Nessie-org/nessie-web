import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GraphService } from '../../services/graph.service';
import { LayoutService } from '../../services/layout.service';

@Component({
  selector: 'app-statusbar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="statusbar">
      <div class="statusbar-left">
        <span class="status-indicator" [class.connected]="!!(graphService.graph$ | async)"></span>
        @if (graphService.graph$ | async; as graph) {
          <span class="status-item accent">{{ graph.name }}</span>
          <span class="status-sep">|</span>
          <span class="status-item">{{ graph.nodes.length }} nodes</span>
          <span class="status-sep">|</span>
          <span class="status-item">{{ graph.edges.length }} edges</span>
          <span class="status-sep">|</span>
          <span class="status-item">{{ graph.directed ? 'Directed' : 'Undirected' }}</span>
        } @else {
          <span class="status-item dim">No graph loaded</span>
        }
      </div>
      <div class="statusbar-right">
        @if (layoutService.selectedNodeId$ | async; as nodeId) {
          <span class="status-item accent">Selected: {{ nodeId }}</span>
          <span class="status-sep">|</span>
        }
        <span class="status-item dim">Nessie Graph Explorer</span>
      </div>
    </div>
  `,
  styles: [`
    :host { display: block; flex-shrink: 0; }
    .statusbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: var(--statusbar-height);
      background: var(--bg-darkest);
      border-top: 1px solid var(--border-dim);
      padding: 0 12px;
      font-family: var(--font-mono);
      font-size: 11px;
    }
    .statusbar-left, .statusbar-right {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .status-indicator {
      width: 7px; height: 7px;
      border-radius: 50%;
      background: var(--text-muted);
      &.connected { background: var(--success); box-shadow: 0 0 6px var(--success); }
    }
    .status-item { color: var(--text-dim); }
    .status-item.accent { color: var(--accent); }
    .status-item.dim { color: var(--text-muted); }
    .status-sep { color: var(--border); }
  `]
})
export class StatusbarComponent {
  graphService  = inject(GraphService);
  layoutService = inject(LayoutService);
}
