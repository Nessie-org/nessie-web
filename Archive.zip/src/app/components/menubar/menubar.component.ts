import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutService, PanelId } from '../../services/layout.service';
import { GraphService } from '../../services/graph.service';

interface MenuItem {
  label: string;
  items: MenuAction[];
}

interface MenuAction {
  type: 'action' | 'separator' | 'toggle';
  label?: string;
  shortcut?: string;
  panelId?: PanelId;
  action?: () => void;
}

@Component({
  selector: 'app-menubar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.scss']
})
export class MenubarComponent implements OnInit {

  layoutService = inject(LayoutService);
  graphService  = inject(GraphService);

  activeMenu: string | null = null;
  panelState$ = this.layoutService.panelState$;

  menus: MenuItem[] = [];

  ngOnInit(): void {
    this.buildMenus();
  }

  private buildMenus(): void {
    this.menus = [
      {
        label: 'File',
        items: [
          { type: 'action', label: 'Open Graph…',        shortcut: 'Ctrl+O', action: () => this.openGraph() },
          { type: 'action', label: 'Load Demo Graph',    shortcut: 'Ctrl+D', action: () => this.graphService.loadDemoGraph() },
          { type: 'separator' },
          { type: 'action', label: 'Export as JSON',     shortcut: 'Ctrl+E', action: () => this.exportGraph() },
          { type: 'separator' },
          { type: 'action', label: 'Exit',               action: () => window.close() },
        ]
      },
      {
        label: 'View',
        items: [
          { type: 'toggle', label: 'Tree View',          shortcut: 'Ctrl+1', panelId: 'treeView' },
          { type: 'toggle', label: 'Bird View',          shortcut: 'Ctrl+2', panelId: 'birdView' },
          { type: 'toggle', label: 'Main View',          shortcut: 'Ctrl+3', panelId: 'mainView' },
          { type: 'separator' },
          { type: 'toggle', label: 'Console',            shortcut: 'Ctrl+`', panelId: 'console' },
          { type: 'separator' },
          { type: 'action', label: 'Reset Layout',       action: () => this.resetLayout() },
        ]
      },
      {
        label: 'Graph',
        items: [
          { type: 'action', label: 'Zoom In',            shortcut: 'Ctrl++', action: () => {} },
          { type: 'action', label: 'Zoom Out',           shortcut: 'Ctrl+-', action: () => {} },
          { type: 'action', label: 'Fit to Screen',      shortcut: 'Ctrl+Shift+F', action: () => {} },
          { type: 'separator' },
          { type: 'action', label: 'Simple Visualizer',  action: () => {} },
          { type: 'action', label: 'Block Visualizer',   action: () => {} },
        ]
      },
      {
        label: 'Help',
        items: [
          { type: 'action', label: 'Documentation',      action: () => {} },
          { type: 'action', label: 'About Nessie…',      action: () => this.showAbout() },
        ]
      }
    ];
  }

  toggleMenu(label: string): void {
    this.activeMenu = this.activeMenu === label ? null : label;
  }

  closeMenus(): void {
    this.activeMenu = null;
  }

  executeAction(item: MenuAction): void {
    if (item.type === 'toggle' && item.panelId) {
      this.layoutService.togglePanel(item.panelId);
    } else if (item.type === 'action' && item.action) {
      item.action();
    }
    this.closeMenus();
  }

  private openGraph(): void {
    this.layoutService.log('info', 'Open graph dialog — not yet implemented');
  }

  private exportGraph(): void {
    const graph = this.graphService.getGraph();
    if (graph) {
      const blob = new Blob([JSON.stringify(graph, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `${graph.name}.json`;
      a.click();
    }
  }

  private resetLayout(): void {
    this.layoutService.log('info', 'Layout reset — reload the page to restore default layout');
    window.location.reload();
  }

  private showAbout(): void {
    this.layoutService.log('info', 'Nessie Graph Explorer v0.1.0 — Graph visualization platform');
  }
}
